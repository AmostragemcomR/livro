###############################################################################
#####  Curso de Amostragem - Edição 2019              
#####  Comandos usados para resolver exercícios da Unidade 06                                  
#####  Programador: Pedro Silva
#####  Atualização: 23/07/2019
################################################################################

# Limpa área de trabalho
rm(list = ls())

# Define pasta onde ficam dados usados nesta sessão
setwd("E:/RJ/Cursos/Amostragem2019/Exercícios 2019")
getwd()

# Carrega biblioteca(s) requerida(s)
library(sampling)
library(tidyverse)

# Leitura dos dados
MunicBR_dat <- readRDS(file="MunicBR_dat.rds")
str(MunicBR_dat)

# Cria código de região nos dados da população
reglabels = c("Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste")
MunicBR_dat <- mutate(MunicBR_dat,
                      Regiao = substr(CodUF,1,1))  %>%
               mutate(Regiao = factor(Regiao, labels=reglabels))
table(MunicBR_dat$Regiao)  

# Define senha para geração de números aleatórios para permitir repetição
set.seed(123)

# Exercício 6.1
# Tamanho da amostra
(n <- 250)
# Tamanho da popul??o
(N <- nrow(MunicBR_dat))

# Seleciona amostra AAS dos municípios
munic_amo <- getdata(MunicBR_dat, srswor(n,N))
str(munic_amo)
table(munic_amo$Regiao)

# Estima população total por macro-região
# Calcula as contagens populacionais por domínio
(N_d <- MunicBR_dat %>%
        group_by(Regiao) %>%
        summarise(N_d = n()) %>%
        select(Regiao, N_d) )

# Calcula médias amostrais por domínio
(ybar_d <- munic_amo %>%
    group_by(Regiao) %>%
    summarise(ybar_d = mean(Pop),
              t_d = sum(Pop)) %>%
    select(Regiao, ybar_d, t_d) )
# Junta informações das duas tabelas por Região
resumo_regiao <- left_join(N_d, ybar_d, by=c("Regiao"))
# Calcula estimativas dos totais, supondo contagens populacionais conhecidas
(Total_reg_est1 <- resumo_regiao %>%
   mutate(Total_reg_est1 = N_d * ybar_d) %>%
   select(Regiao, Total_reg_est1))
# Calcula estimativas dos totais, supondo contagens populacionais desconhecidas
(Total_reg_est2 <- resumo_regiao %>%
    mutate(Total_reg_est2 = N * t_d / n) %>%
    select(Regiao, Total_reg_est2))    
# Calcula totais populacionais para comparação
(Total_reg_pop <- MunicBR_dat %>%
    group_by(Regiao) %>%    
    summarise(Total_reg_pop = sum(Pop)) %>%
    select(Regiao, Total_reg_pop))


# Estima densidade habitacional m?dia por km2 no Brasil
(r_chapeu <- munic_amo %>%
             summarise(Popm = mean(Pop),
                       Aream = mean(Area)) %>%
             mutate(Densm = Popm / Aream) %>%
             select(Densm))

# Estima m?dia da densidade habitacional por km2 por munic?pio
(media.densidade <- munic_amo %>%
                    summarise(Densm = mean(Densidade)))

# Adiciona valor de r_chapeu aos dados da amostra
munic_amo <- cbind(munic_amo, r_chapeu)

# Exerc?cio 2a
(precisao.r_chapeu <- munic_amo %>% 
                     mutate(Z = Pop - Densm * Area) %>%
                     summarise(varZ = var(Z),
                               Aream = mean(Area),
                               Densm = mean(Densm)) %>%
                     mutate(dp.r_chapeu = sqrt((1/n - 1/N)*varZ)/Aream, 
                            cv.r_chapeu = 100 * dp.r_chapeu / Densm)  %>%
                     select(dp.r_chapeu, cv.r_chapeu))

# Exerc?cio 2b
(precisao.media.densidade <- munic_amo %>%
         summarise(Densv = var(Densidade),
                   Densm = mean(Densidade)) %>%
         mutate(dp.media.dens = sqrt((1/n - 1/N)*Densv),
                cv.media.dens = 100 * dp.media.dens / Densm) %>%
         select(dp.media.dens, cv.media.dens))
 
# Calcula densidade habitacional m?dia por km2 no Brasil
(R <- MunicBR_dat %>%
      summarise(Popm = mean(Pop),
                Aream = mean(Area)) %>%
      mutate(Densidade_pop = Popm / Aream) %>%
      select(Densidade_pop))   

# Estima m?dia da densidade habitacional por km2 por munic?pio
(densidade_media_pop <- MunicBR_dat %>%
    summarise(densidade_media_pop = mean(Densidade)))


